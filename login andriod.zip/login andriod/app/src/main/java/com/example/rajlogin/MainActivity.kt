package com.example.rajlogin

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var usernameField: EditText
    private lateinit var passwordField: EditText
    private lateinit var loginBtn: Button
    private lateinit var rememberMe: CheckBox

    private val client = OkHttpClient()
    private val TAG = "LoginDebug"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        usernameField = findViewById(R.id.username)
        passwordField = findViewById(R.id.password)
        loginBtn = findViewById(R.id.loginBtn)
        rememberMe = findViewById(R.id.rememberMe)

        // ⬇️ Move this code INSIDE onCreate
        val goToSignup = findViewById<TextView>(R.id.gotoSignup)
        goToSignup.setOnClickListener {
            startActivity(Intent(this, SignupActivity::class.java))
        }

        val prefs = getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)
        if (prefs.getBoolean("remember", false)) {
            usernameField.setText(prefs.getString("username", ""))
            passwordField.setText(prefs.getString("password", ""))
            rememberMe.isChecked = true
        }

        loginBtn.setOnClickListener {
            val username = usernameField.text.toString().trim()
            val password = passwordField.text.toString().trim()

            Log.d(TAG, "Attempting login with: $username / $password")

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val formBody = FormBody.Builder()
                .add("username", username)
                .add("password", password)
                .build()

            val request = Request.Builder()
                .url("http://192.168.0.230/login.php")
                .post(formBody)
                .build()

            Log.d(TAG, "Sending request to: ${request.url}")

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    Log.e(TAG, "HTTP request failed: ${e.message}")
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "Connection failed", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    val responseText = response.body?.string() ?: "null"
                    Log.d(TAG, "Server response: $responseText")
                    runOnUiThread {
                        if (responseText.contains("success", ignoreCase = true)) {
                            Toast.makeText(this@MainActivity, "Login Successful", Toast.LENGTH_SHORT).show()
                            if (rememberMe.isChecked) {
                                prefs.edit().apply {
                                    putString("username", username)
                                    putString("password", password)
                                    putBoolean("remember", true)
                                    apply()
                                }
                            } else {
                                prefs.edit().clear().apply()
                            }
                        } else {
                            Toast.makeText(this@MainActivity, "Invalid credentials", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            })
        }
    }
}
