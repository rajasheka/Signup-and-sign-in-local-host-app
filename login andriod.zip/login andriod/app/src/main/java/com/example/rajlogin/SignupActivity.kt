package com.example.rajlogin

import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import java.io.IOException

class SignupActivity : AppCompatActivity() {

    private val TAG = "SignupDebug"
    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        val usernameField = findViewById<EditText>(R.id.signupUsername)
        val passwordField = findViewById<EditText>(R.id.signupPassword)
        val signupBtn = findViewById<Button>(R.id.signupButton)
        val goToLogin = findViewById<TextView>(R.id.gotoLogin)

        // 🔙 Back to login screen
        goToLogin.setOnClickListener {
            finish()
        }

        signupBtn.setOnClickListener {
            val username = usernameField.text.toString().trim()
            val password = passwordField.text.toString().trim()

            Log.d(TAG, "Signup button clicked")
            Log.d(TAG, "Username: $username, Password: $password")

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val formBody = FormBody.Builder()
                .add("username", username)
                .add("password", password)
                .build()

            val request = Request.Builder()
                .url("http://192.168.0.230/signup.php")  // Update with your local server
                .post(formBody)
                .build()

            Log.d(TAG, "Sending signup request to: ${request.url}")

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    Log.e(TAG, "Signup request failed: ${e.message}")
                    runOnUiThread {
                        Toast.makeText(this@SignupActivity, "Signup failed", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    val responseText = response.body?.string()
                    Log.d(TAG, "Server response: $responseText")

                    runOnUiThread {
                        if (responseText?.contains("success", ignoreCase = true) == true) {
                            Toast.makeText(this@SignupActivity, "Signup successful!", Toast.LENGTH_SHORT).show()
                            finish()
                        } else {
                            Toast.makeText(this@SignupActivity, "Signup failed: $responseText", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            })
        }
    }
}
